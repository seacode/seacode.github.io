# Making documentation
Simply type 
`make`     

after cloning.


Requires doxygen to be installed